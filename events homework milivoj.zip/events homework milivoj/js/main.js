
function visibilityOn() {
	setTimeout(function(){
	
	 document.getElementById("interactiveBox").style.visibility="visible";
	},3000)

}





function posCenter(){
	 var verticalCenter = Number(window.innerHeight)/2,
	 horisontalCenter = Number(window.innerWidth)/2,
	 boxHeight = Number(document.getElementById("interactiveBox").clientHeight),
	 boxWidth = Number(document.getElementById("interactiveBox").clientWidth);

	document.getElementById("interactiveBox").style.top=(verticalCenter-boxHeight/2) + "px";
	document.getElementById("interactiveBox").style.left=(horisontalCenter-boxWidth/2) + "px";

}


// ono sto mi ovde pola dana nije jasno jeste zasto to ne radi sa var height/width = document.getElementById("interactiveBox").syle.height/width;
// neki lik na netu mi je rekao, a i to mi je jedino razumno objasnjenje, da .style.height/width radi samo sa inline elementima..







